import json
import re
import os


fwc = []
error = []
final_data = []


# 返回所有数据中 code_string中同时含有函数和注释的数据
def file_function_comment():
    ffc = []
    data = []
    with open('./r_data.json', 'r', encoding='UTF-8') as fp:
        for line in fp.readlines():
            dic = json.loads(line)
            data.append(dic)

    print("total:" + str(len(data)))

    countc = 0
    countf = 0
    for i in data:
        if 'code_string' in i:
            countc += 1
            if 'function' in i['code_string']:
                countf += 1
                if '#' in i['code_string'] and i['path'].find('test') < 0:
                    ffc.append(i)
    to_json(ffc, 'r_filehasfunccomment.json')


def to_json(name, filename):
    with open(filename, 'w', encoding='utf-8') as file_obj:
        json.dump(name, file_obj, ensure_ascii=False)


def to_jsonl(name, filename):
    f = open(filename, 'w', encoding='utf-8')
    for i in name:
        json.dump(i, f)
        f.write('\n')


# 提取带有注释的函数 首先只考虑#类型的注释
# 要求以#开头的下一行还是以#开头 或是以function开头
def function_with_comment():
    with open('r_filehasfunccomment.json', 'r', encoding='UTF-8') as f:
        data = json.load(f)
    try:
        for i in data:
            code = i['code_string']
            # 写入临时文件 之后以文件流读取
            tem_file = open('tem.txt', 'w', encoding='UTF-8')
            tem_file.write(code)
            tem_file.close()
            # 从临时文件中读取所有行
            tem_file = open('tem.txt', 'r', encoding='UTF-8')
            all_lines = tem_file.readlines()
            tem_file.close()
            # 开始对每行处理
            j = 0
            while j < len(all_lines):
                line = all_lines[j].strip()
                if line != '':
                    index = line.find('#')
                    if index == 0:  # 找到单独一行注释的行
                        comment_l = 1  # 注释的行数
                        comment = [line]  # 存储注释
                        # 一直读取完连着的#开头的行 CAT
                        while j + comment_l < len(all_lines) and all_lines[j + comment_l].lstrip().startswith('#'):
                            comment.append(all_lines[j + comment_l])
                            comment_l += 1
                        # 看下一行是不是含有<- function
                        if j + comment_l < len(all_lines) and all_lines[j + comment_l].find('<- function') > 0:
                            function_l = 1  # 函数代码的行数
                            original_code = all_lines[j + comment_l]
                            function = [original_code.replace('\n', '').strip()]
                            # 一直读取到函数结束 直到{ }个数相同
                            count_left = ' '.join(function).count('{')
                            count_right = ' '.join(function).count('}')

                            while j + comment_l + function_l < len(all_lines) and count_left != count_right :
                                function.append(all_lines[j + comment_l + function_l].replace('\n', '').strip())
                                count_left = ' '.join(function).count('{')
                                count_right = ' '.join(function).count('}')
                                function_l += 1
                            # 得到一对完整的函数与注释
                            item = {
                                "path": i['path'],
                                "language": "r",
                                "code": function,
                                "docstring": "\n".join(comment)
                            }
                            fwc.append(item)
                            j = j + comment_l + function_l + 1
                        else:
                            j = j + comment_l + 1
                    else:
                        j += 1
                else:
                    j += 1
    except Exception as e:
        error.append(i)
        print(i)
        print(e)


if __name__ == '__main__':
    file_function_comment()
    function_with_comment()
    # 去除空docstring
    count = 0
    delete = []
    for i in fwc:
        docstring = i['docstring']
        r = re.compile('^[#\'-=\*\s]*$')
        if r.search(docstring):
            count += 1
            delete.append(i)
    for i in delete:
        fwc.remove(i)

    to_jsonl(fwc, 'r_original_pair.jsonl')

    try:
        os.remove("r_filehasfunccomment.json")
        os.remove("tem.txt")
    except Exception as e:
        print(e)
        pass
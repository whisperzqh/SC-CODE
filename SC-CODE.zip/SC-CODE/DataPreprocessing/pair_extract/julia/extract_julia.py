import json
import re
import os


fwc = []
error = []
final_data = []


# 返回所有数据中 code_string中同时含有函数和注释的数据
def file_function_comment():
    ffc = []
    data = []
    with open('./julia_data.json', 'r', encoding='UTF-8') as fp:
        for line in fp.readlines():
            dic = json.loads(line)
            data.append(dic)

    print("total:" + str(len(data)))
    for i in data:
        if 'code_string' in i:
            if 'function' in i['code_string']:
                if '#' in i['code_string'] and i['path'].find('test') < 0:
                    ffc.append(i)
    to_json(ffc, 'julia_filehasfunccomment.json')
    fp.close()


def to_json(name, filename):
    with open(filename, 'w', encoding='utf-8') as file_obj:
        json.dump(name, file_obj, ensure_ascii=False)


def to_jsonl(name, filename):
    f = open(filename, 'w', encoding='utf-8')
    for i in name:
        json.dump(i, f)
        f.write('\n')


# 提取带有注释的函数 首先只考虑#类型的注释
# 要求以#开头的下一行还是以#开头 或是以function开头
def function_with_comment():
    with open('./julia_filehasfunccomment.json', 'r', encoding='UTF-8') as f:
        data = json.load(f)
    try:
        for i in data:
            code = i['code_string']
            # 写入临时文件 之后以文件流读取
            tem_file = open('tem.txt', 'w', encoding='UTF-8')
            tem_file.write(code)
            tem_file.close()
            # 从临时文件中读取所有行
            tem_file = open('tem.txt', 'r', encoding='UTF-8')
            all_lines = tem_file.readlines()
            tem_file.close()
            # 开始对每行处理
            j = 0
            while j < len(all_lines):
                line = all_lines[j].strip()
                if line != '':
                    index = line.find('#')
                    if index == 0:  # 找到单独一行注释的行
                        comment_l = 1  # 注释的行数
                        comment = [line]  # 存储注释
                        # 一直读取完连着的#开头的行 CAT
                        while j + comment_l < len(all_lines) and all_lines[j + comment_l].lstrip().startswith('#'):
                            comment.append(all_lines[j + comment_l])
                            comment_l += 1
                        # 看下一行是不是function开头 注意：function前可能含有类似@generated,也有可能行首出现
                        is_function = False
                        if j + comment_l < len(all_lines):
                            line_after_comment = all_lines[j + comment_l]
                            if line_after_comment.strip().startswith('function '):
                                # 如果以function开头需要判断是不是一个单独的关键字
                                is_function = True
                            elif line_after_comment.strip().startswith('@') and line_after_comment.strip().find(
                                    ' function ') > 0:
                                # 如果不是以function开头 判断是不是前面存在其他的关键字
                                is_function = True

                            # 如果是function的话 开始处理
                            if is_function:
                                function_l = 1  # 函数代码的行数
                                original_code = all_lines[j + comment_l]
                                original_len = len(original_code)
                                # 如果函数只有一行 类似 function origin end
                                if original_code.strip().endswith(' end'):
                                    function = original_code.strip()
                                # 如果是正常情况 函数有好几行
                                else:
                                    left_space_len = original_len - len(original_code.lstrip())  # 左起缩进空格数
                                    function = [original_code.replace('\n', '').strip()]
                                    # 一直读取到函数结束 找到相同缩进的end
                                    # 如果找不到相同缩进的end 就舍弃
                                    while not (all_lines[j + comment_l + function_l].strip().startswith('end')
                                               and len(all_lines[j + comment_l + function_l]) - len(
                                                all_lines[j + comment_l + function_l].lstrip()) == left_space_len):
                                        function.append(all_lines[j + comment_l + function_l].replace('\n', '').strip())

                                        function_l += 1
                                        if j + comment_l + function_l >= len(all_lines):
                                            is_function = False
                                            break
                                    # 处理最后一个end
                                    if is_function:
                                        function.append(all_lines[j + comment_l + function_l].replace('\n', '').strip())

                                    # 得到一对完整的函数与注释
                                if is_function:
                                    item = {
                                        "path": i['path'],
                                        "language": "julia",
                                        "code": function,
                                        "docstring": "\n".join(comment)
                                    }
                                    fwc.append(item)
                                j = j + comment_l + function_l + 1
                            else:
                                j = j + comment_l + 1
                        else:
                            j = j + comment_l + 1
                    else:
                        j += 1
                else:
                    j += 1
    except Exception as e:
        error.append(i)
        print(i)
        print(e)


if __name__ == '__main__':
    file_function_comment()
    function_with_comment()
    # 去除空docstring
    count = 0
    delete = []
    for i in fwc:
        docstring = i['docstring']
        r = re.compile('^[#-=\*\s]*$')
        if r.search(docstring):
            count += 1
            delete.append(i)
    for i in delete:
        fwc.remove(i)
    to_jsonl(fwc, 'julia_original_pair.jsonl')

    try:
        os.remove("julia_filehasfunccomment.json")
        os.remove("tem.txt")
    except Exception as e:
        print(e)
        pass

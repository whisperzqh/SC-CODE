import json
import re
import os


fwc = []
error = []
function_list = []
split_function_list = []
final_data =[]


# 返回所有数据中 code_string中同时含有函数和注释的数据
def file_function_comment():
    ffc = []
    data = []
    with open('matlab_data.json', 'r', encoding='UTF-8') as fp:
        for line in fp.readlines():
            dic = json.loads(line)
            data.append(dic)
    print("total:" + str(len(data)))

    countc = 0
    countf = 0
    for i in data:
        if 'code_string' in i:
            countc += 1
            if 'function' in i['code_string']:
                countf += 1
                if '%' in i['code_string'] and i['path'].find('test') < 0:
                    ffc.append(i)
    to_json(ffc, 'matlab_filehasfunccomment.json')


def to_json(name, filename):
    with open(filename, 'w', encoding='utf-8') as file_obj:
        json.dump(name, file_obj, ensure_ascii=False)


def to_jsonl(name, filename):
    f = open(filename, 'w', encoding='utf-8')
    for i in name:
        json.dump(i, f)
        f.write('\n')


# 提取带有注释的函数 首先只考虑%类型的注释
# 要求以%开头的下一行还是以%开头 或是以function开头
def function_with_comment():
    with open('matlab_filehasfunccomment.json', 'r', encoding='UTF-8') as f:
        data = json.load(f)
    try:
        for i in data:
            code = i['code_string']
            # 写入临时文件 之后以文件流读取
            tem_file = open('tem.txt', 'w', encoding='UTF-8')
            tem_file.write(code)
            tem_file.close()
            # 从临时文件中读取所有行
            tem_file = open('tem.txt', 'r', encoding='UTF-8')
            all_lines = tem_file.readlines()
            tem_file.close()
            # 开始对每行处理
            j = 0
            while j < len(all_lines):
                line = all_lines[j].lstrip()
                if line != '':
                    index = line.find('%')
                    if index < 0:  # 如果不是注释行
                        if line.find('function') == 0:  # 以function开头
                            function = [line]
                            function_l = 1
                            begin = 1  # 需要接begin的词个数 function if Switch for while
                            end = 0  # end个数
                            while j + function_l < len(all_lines):
                                current_line = all_lines[j + function_l].lstrip()
                                function.append(current_line)
                                function_l += 1
                                if current_line.find('%') != 0:
                                    if current_line.find('if') == 0 or current_line.find(
                                            'switch') == 0 or current_line.find('for') == 0 or current_line.find(
                                            'while') == 0 or current_line.find('function') == 0:
                                        begin += 1
                                    if (not current_line.startswith('%')) and re.search('(end\s*)$',current_line):
                                        end += 1
                                if begin == end:
                                    while '' in function:  # 去除主函数不含有注释的
                                        function.remove("")
                                    if function[1].find('%') == 0:
                                        item = {
                                            'path': i['path'],
                                            'function': function
                                        }
                                        function_list.append(item)
                                    break
                            j += function_l
                        else:
                            j += 1
                    else:
                        j += 1
                else:
                    j += 1
    except Exception as e:
        error.append(i)
        print(i)
        print(e)


# 拆分出来function里面嵌套的function
def split_function_with_comment():
    with open('func_list.json', 'r', encoding='UTF-8') as f:
        data = json.load(f)
    for i in data:
        function = i['function']
        comment = []
        # 先找到大函数的注释部分
        j = 1
        while function[j].startswith('%'):
            comment.append(function[j])
            # 从code中去除这部分注释
            function.pop(j)
        # 存储大函数
        item = {
            "path": i['path'],
            "language": "matlab",
            "code": function,
            "docstring": "\n".join(comment)
        }
        split_function_list.append(item)
        # 识别嵌套的小函数
        while j < len(function):
            # 找到function所在行
            if function[j].startswith("function"):
                # 查看前后是否有注释
                comment = []
                comment_l = 0
                begin = 0
                end = 0
                function_split = []
                if function[j + 1].startswith("%") and j + 1 < len(function):
                    while function[j + 1 + comment_l].startswith("%"):
                        comment.append(function[j + 1 + comment_l])
                        comment_l += 1
                    # 在code中去掉注释
                    del function[j + 1:j + 1 + comment_l]
                    # code部分
                    while j < len(function):
                        current_line = function[j]
                        function_split.append(current_line)
                        j += 1
                        if (current_line.find('if') == 0 or current_line.find('switch') == 0 or current_line.find(
                                'for') == 0 or current_line.find('while') == 0 or current_line.find('function') == 0):
                            begin += 1
                        if (not current_line.startswith("%")) and re.search('(end\s*)$',current_line):
                            end += 1
                        if begin == end:
                            item = {
                                "path": i['path'],
                                "language": "matlab",
                                "code": function_split,
                                "docstring": "\n".join(comment)
                            }
                            split_function_list.append(item)
                            break
                elif function[j - 1].startswith("%"):
                    while function[j - 1 - comment_l].startswith("%"):
                        comment.insert(0, function[j - 1 - comment_l])
                        comment_l += 1
                    # code部分
                    while j < len(function):
                        current_line = function[j]
                        function_split.append(current_line)
                        j += 1
                        if current_line.find('if') == 0 or current_line.find('switch') == 0 or current_line.find(
                                'for') == 0 or current_line.find('while') == 0 or current_line.find('function') == 0:
                            begin += 1
                        if re.search('(end\s*)$',current_line):
                            end += 1
                        if begin == end:
                            item = {
                                "path": i['path'],
                                "language": "matlab",
                                "code": function_split,
                                "docstring": "\n".join(comment)
                            }
                            split_function_list.append(item)
                            break
                else:
                    j += 1
            else:
                j += 1


if __name__ == '__main__':
    file_function_comment()
    function_with_comment()
    to_json(function_list, 'func_list.json')
    to_json(error, 'test.json')

    split_function_with_comment()
    to_json(split_function_list, 'func_list_split.json')

    with open('func_list_split.json', 'r', encoding="utf-8") as f:
        data = json.load(f)
    # 去除空docstring
    count = 0
    delete = []
    for i in data:
        docstring = i['docstring']
        r = re.compile('^[%(\{)(\})-=\*\s]*$')
        if r.search(docstring):
            count += 1
            delete.append(i)
    for i in delete:
        data.remove(i)
    to_jsonl(data, 'matlab_original_pair.jsonl')

    try:
        os.remove("matlab_filehasfunccomment.json")
        os.remove("tem.txt")
        os.remove("func_list_split.json")
        os.remove("func_list.json")
        os.remove("test.json")
    except Exception as e:
        print(e)
        pass

import json
import random
import pandas
import os

from transformers import AutoTokenizer, RobertaTokenizer, RobertaModel

final_data = []
pre_data = []


def to_final_data():
    data = []
    with open('matlab_CAT_pair.jsonl', 'r', encoding='utf-8') as f:
        for line in f:
            data.append(json.loads(line.rstrip('\n|\r')))

    special_tokens = ['classdef', 'elseif', 'parfor', 'Inf', 'ifelse','ans','eps','inf','NaN','nargin','nargout','realmin','realmax']
    tokenizer = RobertaTokenizer.from_pretrained('roberta-base')
    model = RobertaModel.from_pretrained("roberta-base")
    tokenizer.add_tokens(special_tokens)
    model.resize_token_embeddings(len(tokenizer))

    for i in range(len(data)):
        code = ' '.join(data[i]['code'].strip().split())
        t = tokenizer.tokenize(code)

        doc = ' '.join(data[i]['docstring'].replace('%', '').replace('-','').replace('*','').strip().split())
        d = tokenizer.tokenize(doc)

        item = {
            "path": data[i]['path'],
            "language": data[i]['language'],
            "code": data[i]['code'],
            "code_tokens": t,
            "docstring": data[i]['docstring'],
            "docstring_tokens": d
        }
        final_data.append(item)


def to_jsonl(name, filename):
    f = open(filename, 'w', encoding='utf-8')
    for i in name:
        json.dump(i, f, ensure_ascii=False)
        f.write('\n')


def preprocess():
    with open('matlab_CAT_pair_tokenizer.jsonl', 'r', encoding='UTF-8') as f:
        for line in f:
            pre_data.append(json.loads(line.rstrip('\n|\r')))
    for i in pre_data:
        l = len(i['docstring_tokens'])
        if l < 3 or l > 256:
            pre_data.remove(i)


def split(train_rate, valid_rate, test_rate):
    # 划分train valid test 8:1:1
    l = len(pre_data)
    valid_num = int(l * valid_rate)
    test_num = int(l * test_rate)

    valid_sample = random.sample(pre_data, valid_num)
    for s in valid_sample:
        pre_data.remove(s)
        s['partition'] = 'valid'
    df = pandas.DataFrame(valid_sample)
    df.to_json("valid.jsonl", orient="records", force_ascii=False, lines="orient")

    test_sample = random.sample(pre_data, test_num)
    for s in test_sample:
        pre_data.remove(s)
        s['partition'] = 'test'
    df = pandas.DataFrame(test_sample)
    df.to_json("test.jsonl", orient="records", force_ascii=False, lines="orient")

    for s in pre_data:
        s['partition'] = 'train'
    df = pandas.DataFrame(pre_data)
    df.to_json("train.jsonl", orient="records", force_ascii=False, lines="orient")


if __name__ == '__main__':
    to_final_data()
    to_jsonl(final_data, 'matlab_CAT_pair_tokenizer.jsonl')

    preprocess()
    split(0.8,0.1,0.1)

    try:
        os.remove("matlab_CAT_pair.jsonl")
        os.remove("matlab_CAT_pair_tokenizer.jsonl")
    except Exception as e:
        print(e)
        pass
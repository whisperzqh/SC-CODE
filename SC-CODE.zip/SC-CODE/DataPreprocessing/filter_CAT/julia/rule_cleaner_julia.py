from noise_detection_julia import *
from tqdm import tqdm
from bs4 import BeautifulSoup
import json


class RuleCleaner(object):
    def __init__(self, raw_path_list, raw_code_list, raw_comment_list):
        """
        :param raw_code_list: list of raw code
        :param raw_comment_list: list of raw comments
        """
        assert len(raw_path_list) == len(raw_code_list) == len(raw_comment_list)
        self.raw_path_list = raw_path_list
        self.raw_code_list = raw_code_list
        self.raw_comment_list = raw_comment_list
        self.output_dict = {}
        self.cleaned_code_list = []
        self.cleaned_comment_list = []
        self.cleaned_path_list = []
        # since detecting `Partial Sentence', `Verbose Sentence', `Over-Splitting' noise requires comparing
        # the updated comment with the benchmark comment, users can detect these noises using the functions defined
        # in the `noise_detection' file
        self.noisy_data = {'ContentTamper': [], 'NonLiteral': [], 'Interrogation': [], 'UnderDevelop': [],
                           'EmptyFunc': [], 'CommentOut': [], 'BlockComment': [], 'AutoCode': [], 'DuplicatedCode': []}

    def get_clean_data(self):
        for path, raw_code, raw_comment in tqdm(zip(self.raw_path_list, self.raw_code_list, self.raw_comment_list)):
            firstSentence = getFirstSentence(raw_comment)
            updated_comment = self.update_ContentTamper(firstSentence)
            if updated_comment != firstSentence:
                self.noisy_data['ContentTamper'].append((path, raw_code, raw_comment))
            # remove rules
            if if_ContentTamper(updated_comment):
                self.noisy_data['ContentTamper'].append((path, raw_code, raw_comment))
                continue
            if if_NonLiteral(updated_comment):
                self.noisy_data['NonLiteral'].append((path, raw_code, raw_comment))
                continue
            if if_Interrogation(updated_comment):
                self.noisy_data['Interrogation'].append((path, raw_code, raw_comment))
                continue
            if if_UnderDevelop(updated_comment):
                self.noisy_data['UnderDevelop'].append((path, raw_code, raw_comment))
                continue
            if if_AutoCode_by_comment(updated_comment, raw_comment):
                self.noisy_data['AutoCode'].append((path, raw_code, raw_comment))
                continue

            if if_CommentedOut(raw_code):
                self.noisy_data['CommentOut'].append((path, raw_code, raw_comment))
                continue
            updated_code = self.update_BlockComment(raw_code)
            if updated_code != raw_code:
                self.noisy_data['BlockComment'].append((path, raw_code, raw_comment))
            if if_AutoCode_by_code(updated_code):
                self.noisy_data['AutoCode'].append((path, raw_code, raw_comment))
                continue
            if if_EmptyFunc(updated_code):
                self.noisy_data['EmptyFunc'].append((path, raw_code, raw_comment))
                continue

            if self.output_dict.get(updated_code) is None:
                self.output_dict[updated_code] = {
                    'update_comment': [updated_comment],
                    'path': [path]
                }
            else:
                self.output_dict[updated_code]['update_comment'].append(updated_comment)
                self.output_dict[updated_code]['path'].append(path)
        # remove duplicated code
        for updated_code in self.output_dict:
            self.cleaned_code_list.append(updated_code)
            updated_comment_list = self.output_dict[updated_code]['update_comment']
            path_list = self.output_dict[updated_code]['path']
            if len(updated_comment_list) > 1:
                self.noisy_data['DuplicatedCode'].append((updated_code, updated_comment_list, path_list))
                self.cleaned_comment_list.append(updated_comment_list[0])
                self.cleaned_path_list.append(path_list[0])
            else:
                self.cleaned_comment_list.append(updated_comment_list[0])
                self.cleaned_path_list.append(path_list[0])

        return self.cleaned_path_list, self.cleaned_code_list, self.cleaned_comment_list

    def get_noisy_data(self):
        return self.noisy_data

    def update_BlockComment(self, raw_code):
        p = re.compile('^(\s+#)|(#)')
        new_list = []
        for row in raw_code.split('\n'):
            if not p.search(row):
                new_list.append(row)
        return '\n'.join(new_list)

    def update_ContentTamper(self, comment):
        return BeautifulSoup(comment, "html.parser").get_text()

def to_jsonl(name, filename):
        f = open(filename, 'w', encoding='utf-8')
        for i in name:
            json.dump(i, f)
            f.write('\n')


if __name__ == '__main__':
    with open('../../pair_extract/julia/julia_original_pair.jsonl', 'r', encoding='UTF-8') as f:
        data_lines = f.readlines()

    raw_path_list, raw_code_list, raw_comment_list = [], [], []
    for line in data_lines:
        json_line = json.loads(line.strip())
        raw_code_list.append('\n'.join(json_line['code']))
        raw_comment_list.append(json_line['docstring'])
        raw_path_list.append(json_line['path'])

    cleaner = RuleCleaner(raw_path_list, raw_code_list, raw_comment_list)
    cleaned_path, cleaned_code, cleaned_comment = cleaner.get_clean_data()

    # print(len(cleaner.get_noisy_data()['ContentTamper']))
    # print(len(cleaner.get_noisy_data()['NonLiteral']))
    # print(len(cleaner.get_noisy_data()['Interrogation']))
    # print(len(cleaner.get_noisy_data()['UnderDevelop']))
    # print(len(cleaner.get_noisy_data()['EmptyFunc']))
    # print(len(cleaner.get_noisy_data()['CommentOut']))
    # print(len(cleaner.get_noisy_data()['BlockComment']))
    # print(len(cleaner.get_noisy_data()['AutoCode']))
    # print(len(cleaner.get_noisy_data()['DuplicatedCode']))

    item_list = []
    for i in range(0,len(cleaned_code)):
        item = {
            'path': cleaned_path[i],
            'code': cleaned_code[i],
            'docstring': cleaned_comment[i],
            'language': 'julia'
        }
        item_list.append(item)
    to_jsonl(item_list,"julia_CAT_pair.jsonl")
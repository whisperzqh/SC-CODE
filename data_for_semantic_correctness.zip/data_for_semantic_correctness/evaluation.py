from typing import Optional, Callable, Dict
import ast
import contextlib
import faulthandler
import io
import os
import multiprocessing
import platform
import signal
import tempfile
import subprocess
import threading
import json
import matlab.engine


# import rpy2.robjects as robjects

def read_jsonl(file):
    data = []
    f = open(file, 'r', encoding='utf-8')
    for l in f.readlines():
        data.append(json.loads(l))
    f.close()
    return data


def check_correctness(language, problem: Dict, check_program: str, timeout: float,
                      completion_id: Optional[int] = None) -> Dict:
    result = []

    try:
        with swallow_io():
            if language == 'julia':
                run_with_timeout(exec_julia, timeout=3, check_program=check_program)
            elif language == 'r':
                run_with_timeout(exec_r, timeout=3, check_program=check_program)
            elif language == 'matlab':
                eng = matlab.engine.start_matlab()
                run_with_timeout(exec_matlab, timeout=3, check_program=check_program, eng=eng)
        result.append("passed")
    except TimeoutException:
        result.append("timed out")
    except BaseException as e:
        result.append(f"failed: {e}")

    if not result:
        result.append("timed out")

    return dict(
        task_id=problem["task_id"],
        passed=result[0] == "passed",
        result=result[0],
        completion_id=completion_id,
    )


def exec_julia(check_program):
    with open("julia_script.jl", "w", encoding='utf-8') as file:
        file.write(check_program)
    command = ["julia", "julia_script.jl"]
    subprocess.run(command, capture_output=True, text=True, check=True)


def exec_r(check_program):
    with open("r_script.r", "w", encoding='utf-8') as file:
        file.write(check_program)
    command = ['Rscript', "r_script.r"]
    subprocess.run(command, capture_output=True, text=True, check=True)


def exec_matlab(check_program, eng):
    with open("matlab_script.m", "w", encoding='utf-8') as file:
        file.write("function result = matlab_script()\nformat longG;\n\n" + check_program + "\nresult=1;\nend\n")
    eng.matlab_script()
    eng.quit()


@contextlib.contextmanager
def swallow_io():
    stream = WriteOnlyStringIO()
    with contextlib.redirect_stdout(stream):
        with contextlib.redirect_stderr(stream):
            with redirect_stdin(stream):
                yield


def run_with_timeout(func, timeout, *args, **kwargs):
    result = None
    exception = None

    def target():
        nonlocal result, exception
        try:
            result = func(*args, **kwargs)
        except Exception as e:
            exception = e
            print(e)

    thread = threading.Thread(target=target)
    thread.start()
    thread.join(timeout)

    if thread.is_alive():
        thread.join() 
        raise TimeoutException("Timed out!")

    if exception is not None:
        raise exception

    return result


class TimeoutException(Exception):
    pass


class WriteOnlyStringIO(io.StringIO):
    """ StringIO that throws an exception when it's read from """

    def read(self, *args, **kwargs):
        raise IOError

    def readline(self, *args, **kwargs):
        raise IOError

    def readlines(self, *args, **kwargs):
        raise IOError

    def readable(self, *args, **kwargs):
        """ Returns True if the IO object can be read. """
        return False


class redirect_stdin(contextlib._RedirectStream):  # type: ignore
    _stream = 'stdin'


def extract_code(message, language):
    start = message.find('```' + language) + len('```' + language)
    for stop in range(start, len(message)):
        if message[stop] == '`':
            break
    return message[start: stop]


if __name__ == '__main__':
    truncate_pattern_julia = [r"\n\n^#", "^'''", "\n\n\n"]
    truncate_pattern_r = [r"\n\n^#", "\n\n\n"]
    truncate_pattern_matlab = [r"\n\n^%", "^%{", "\n\n\n"]

    # replace the value of 'langauge', 'model' and 'path'
    language = 'julia'
    model = 'gpt3.5'
    path = '../test_result/' + model + '/' + language + '.jsonl'
    data = read_jsonl(path)
    for i in data:
        if model.startswith('gpt') and '```' in i['result']:
            completion = extract_code(i['result'], language)
            check_program = completion + "\n" + i["test"] + "\n"
        else:
            completion = i['result']
            check_program = (i["prompt"] + completion + "\n" + i["test"] + "\n")
        print(check_correctness(language, i, check_program, 1.0))
